# KRAEZ TWEAKS — Universal Server Selector

A GitHub Pages-ready static website for saving HTTPS probe endpoints, measuring browser-to-endpoint response time, sorting the results, and selecting a local preferred endpoint.

## Run it
1. Download or clone this repository.
2. Open `index.html` in a browser, or enable **GitHub Pages** for the repository (Settings → Pages → deploy from branch → `main` → `/ (root)`).
3. Open the published Pages URL.

## Add an endpoint
Enter a name and an HTTPS URL that the game/server provider publishes for health checks or status probes. Click **Add Endpoint**, then **Test All Saved Endpoints**.

## Important limitations
- The test measures HTTPS response time from the browser to the URL entered. It is **not** guaranteed to equal in-game ping or UDP game-server latency.
- Browsers cannot freely send raw ICMP/UDP ping packets to game servers.
- A universal website cannot discover every game's live server list or move a player between game servers.
- The Select button stores a local preference only. It does not connect to or switch the active game server.
- Real integrations require official game APIs/SDKs, permitted endpoints, and often a native app or in-game integration. Never use undocumented endpoints or bypass a game's protections.

## Extending for a specific game
Add a separate adapter only when the game publisher provides a documented, permitted server-discovery or matchmaking API. Keep credentials on a trusted backend; never put private API keys in client-side JavaScript.
